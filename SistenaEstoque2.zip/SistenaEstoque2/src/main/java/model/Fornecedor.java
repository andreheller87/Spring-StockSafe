package model;

/**
 * 
 * 
 * @author André Heller
 */
public class Fornecedor {
	private int id;
	private String nome;
	private String CNPJ;
	private String Telefone;
	private String endereco;
	private String email;
	private String cep;
}
